package org.pcat.inventory.dao;

public class UserManagementDAO {

}
