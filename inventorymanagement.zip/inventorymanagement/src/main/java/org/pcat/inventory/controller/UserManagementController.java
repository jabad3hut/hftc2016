package org.pcat.inventory.controller;

public class UserManagementController {

}
