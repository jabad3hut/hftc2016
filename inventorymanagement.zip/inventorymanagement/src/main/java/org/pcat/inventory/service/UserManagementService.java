package org.pcat.inventory.service;

public class UserManagementService {

}
